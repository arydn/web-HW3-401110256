import React, { useState } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Canvas from './components/Canvas';
import ShapeCounter from './components/ShapeCounter';
import { ShapeType } from './types/shapes';
import { ShapesProvider } from './context/ShapesContext';
import './styles/App.css';

const App = () => {
  const [selectedShape, setSelectedShape] = useState<ShapeType>('circle');

  return (
    <ShapesProvider>
      <div style={{ display: 'flex' }}>
        <div style={{ flexGrow: 1 }}>
          <Header />
          <Canvas selectedShape={selectedShape} />
        </div>
        <Sidebar selected={selectedShape} onSelect={setSelectedShape} />
      </div>
      <ShapeCounter />
    </ShapesProvider>
  );
};

export default App;
