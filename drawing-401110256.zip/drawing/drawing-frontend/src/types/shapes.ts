export type ShapeType = 'circle' | 'square' | 'triangle';

export interface Shape {
  type: ShapeType;
  x: number;
  y: number;
  id?: string;
}
