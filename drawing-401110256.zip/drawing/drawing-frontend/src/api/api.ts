import { Shape } from '../types/shapes';
import { v4 as uuidv4 } from 'uuid';

const BACKEND_URL = 'http://localhost:8080/api/drawings';

export const saveDrawing = async (
    username: string,
    drawingName: string,
    shapes: Shape[]
): Promise<boolean> => {
    try {
        const shapesToSend = shapes.map(({ type, x, y }) => ({ type, x, y }));

        const payload = {
            username,
            drawingName,
            shapes: shapesToSend
        };

        const response = await fetch(`${BACKEND_URL}/${username}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });

        return response.ok;
    } catch (error) {
        console.error('Failed to save drawing:', error);
        return false;
    }
};


export const fetchDrawing = async (
    username: string
): Promise<{ drawingName: string; shapes: Shape[] } | null> => {
    try {
        const response = await fetch(`${BACKEND_URL}/${username}`);
        if (!response.ok) return null;

        const data = await response.json();

        const cleanShapes: Shape[] = data.shapes.map(
            (shape: { type: string; x: number; y: number }) => ({
                id: uuidv4(), 
                type: shape.type as Shape['type'],
                x: shape.x,
                y: shape.y
            })
        );

        return {
            drawingName: data.drawingName || 'Untitled Drawing',
            shapes: cleanShapes
        };
    } catch (error) {
        console.error('Failed to fetch drawing:', error);
        return null;
    }
};
