// src/api/api.ts
import { Shape } from '../types/shapes';

const BASE_URL = 'http://localhost:8080/api/drawings'; // Adjust if deployed elsewhere

export async function fetchDrawing(username: string): Promise<{ shapes: Shape[]; title: string } | null> {
  try {
    const res = await fetch(`${BASE_URL}/${username}`);
    if (!res.ok) return null;
    const data = await res.json();
    return { shapes: data.shapes || [], title: data.title || 'Untitled Drawing' };
  } catch (err) {
    console.error('Error fetching drawing:', err);
    return null;
  }
}

export async function saveDrawing(username: string, title: string, shapes: Shape[]): Promise<boolean> {
  try {
    const res = await fetch(`${BASE_URL}/${username}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, title, shapes }),
    });
    return res.ok;
  } catch (err) {
    console.error('Error saving drawing:', err);
    return false;
  }
}
