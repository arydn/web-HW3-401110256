import React, { createContext, useContext, useState } from 'react';
import { Shape } from '../types/shapes';

interface ShapesContextType {
  shapes: Shape[];
  setShapes: React.Dispatch<React.SetStateAction<Shape[]>>;
}

const ShapesContext = createContext<ShapesContextType | undefined>(undefined);

export const ShapesProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [shapes, setShapes] = useState<Shape[]>([]);
  return (
    <ShapesContext.Provider value={{ shapes, setShapes }}>
      {children}
    </ShapesContext.Provider>
  );
};

export const useShapes = () => {
  const context = useContext(ShapesContext);
  if (!context) {
    throw new Error('useShapes must be used within a ShapesProvider');
  }
  return context;
};
