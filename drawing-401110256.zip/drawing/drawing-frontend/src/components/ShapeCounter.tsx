import React from 'react';
import { useShapes } from '../context/ShapesContext';
import styles from '../styles/ShapeCounter.module.css';

const ShapeCounter = () => {
  const { shapes } = useShapes();

  const counts = shapes.reduce(
    (acc, shape) => {
      acc[shape.type]++;
      return acc;
    },
    { circle: 0, square: 0, triangle: 0 }
  );

  return (
    <div className={styles.shapeCounter}>
      <span>🟠 Circles: {counts.circle}</span>
      <span>🟦 Squares: {counts.square}</span>
      <span>🔺 Triangles: {counts.triangle}</span>
    </div>
  );
};

export default ShapeCounter;
