import React, { useState } from 'react';
import { Shape, ShapeType } from '../types/shapes';
import { useShapes } from '../context/ShapesContext';
import styles from '../styles/Canvas.module.css';
import { v4 as uuidv4 } from 'uuid';

interface CanvasProps {
  selectedShape: ShapeType;
}

const Canvas: React.FC<CanvasProps> = ({ selectedShape }) => {
  const { shapes, setShapes } = useShapes();
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [dragging, setDragging] = useState(false);
  const [justDropped, setJustDropped] = useState(false);
  const [justDeleted, setJustDeleted] = useState(false);

  const handleClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (dragging || justDropped || justDeleted) {
      setJustDropped(false);
      setJustDeleted(false);
      return;
    }

    const rect = (e.currentTarget as HTMLDivElement).getBoundingClientRect();
    const shapeSize = selectedShape === 'triangle' ? 35 : 40;

    const x = e.clientX - rect.left - shapeSize / 2;
    const y = e.clientY - rect.top - shapeSize / 2;

    const newShape: Shape = {
      id: uuidv4(),
      type: selectedShape,
      x,
      y,
    };
    setShapes((prev) => [...prev, newShape]);
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>, shape: Shape) => {
    e.stopPropagation();
    setDragging(true);
    setDraggingId(shape.id ?? null);

    const rect = e.currentTarget.getBoundingClientRect();
    setOffset({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!draggingId) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left - offset.x;
    const y = e.clientY - rect.top - offset.y;

    setShapes((prev) =>
        prev.map((s) => (s.id === draggingId ? { ...s, x, y } : s))
    );
  };

  const handleMouseUp = () => {
    if (draggingId) {
      setDraggingId(null);
      setDragging(false);
      setJustDropped(true);
    }
  };

  const handleDoubleClick = (id: string) => {
    setShapes((prev) => prev.filter((s) => s.id !== id));
    setJustDeleted(true);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const shapeType = e.dataTransfer.getData('shapeType') as ShapeType;
    if (!shapeType) return;

    const rect = (e.currentTarget as HTMLDivElement).getBoundingClientRect();
    const shapeSize = shapeType === 'triangle' ? 35 : 40;

    const x = e.clientX - rect.left - shapeSize / 2;
    const y = e.clientY - rect.top - shapeSize / 2;

    const newShape: Shape = {
      id: uuidv4(),
      type: shapeType,
      x,
      y,
    };
    setShapes((prev) => [...prev, newShape]);
    setJustDropped(true);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  };

  return (
      <div
          className={styles.canvas}
          onClick={handleClick}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onDrop={handleDrop}
          onDragOver={handleDragOver}
      >
        {shapes.map((shape) => (
            <div
                key={shape.id ?? uuidv4()}
                className={`${styles.drawnShape} ${styles[shape.type]}`}
                style={{ left: shape.x, top: shape.y }}
                onMouseDown={(e) => handleMouseDown(e, shape)}
                onDoubleClick={() => shape.id && handleDoubleClick(shape.id)}
            />
        ))}
      </div>
  );
};

export default Canvas;
