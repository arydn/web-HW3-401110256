import React, { useRef, useState } from 'react';
import { useShapes } from '../context/ShapesContext';
import { Shape } from '../types/shapes';
import styles from '../styles/Header.module.css';
import { fetchDrawing, saveDrawing } from '../api/api';

const Header = () => {
  const { shapes, setShapes } = useShapes();
  const [title, setTitle] = useState('Untitled Drawing');
  const [username, setUsername] = useState('user1');
  const [importedFileName, setImportedFileName] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const exportToBackend = async () => {
    try {
      const success = await saveDrawing(username, title, shapes);
      if (success) {
        alert('✅ Drawing saved to server!');
      } else {
        alert('❌ Failed to save drawing');
      }
    } catch (error) {
      alert('❌ Failed to save drawing (exception)');
    }
  };

  const importFromBackend = async () => {
    try {
      const data = await fetchDrawing(username);
      if (data) {
        setShapes(data.shapes);
        setTitle(data.drawingName || 'Untitled Drawing');
        alert(`✅ Loaded drawing for user "${username}"`);
      } else {
        alert(`❌ No drawing found for user "${username}"`);
      }
    } catch (err) {
      alert('❌ Error loading drawing from server');
    }
  };

  const exportToFile = () => {
    const dataStr = JSON.stringify(shapes, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const sanitizedTitle = title.trim().replace(/\s+/g, '-').toLowerCase();
    const filename = `${sanitizedTitle || 'untitled-drawing'}.json`;

    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      try {
        const importedShapes: Shape[] = JSON.parse(reader.result as string);
        if (!Array.isArray(importedShapes)) throw new Error('Not an array');
        setShapes(importedShapes);
        setImportedFileName(file.name);
        alert(`✅ Imported ${file.name} successfully`);
      } catch (err) {
        alert(`❌ Failed to import ${file.name}: Invalid format`);
      }
    };
    reader.readAsText(file);
  };

  return (
      <div className={styles.header}>
        <div className={styles.inputGroup}>
          <input
              type="text"
              className={styles.titleInput}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Untitled Drawing"
          />
          <input
              type="text"
              className={styles.userInput}
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Username (e.g., user1)"
          />
        </div>
        <div>
          <button onClick={exportToBackend}>Save to Server</button>
          <button onClick={importFromBackend} style={{ marginLeft: '10px' }}>
            Load from Server
          </button>
          <button onClick={exportToFile} style={{ marginLeft: '10px' }}>
            Export JSON
          </button>
          <button onClick={() => fileInputRef.current?.click()} style={{ marginLeft: '10px' }}>
            Import JSON
          </button>
          <input
              type="file"
              accept="application/json"
              ref={fileInputRef}
              onChange={handleImportFile}
              style={{ display: 'none' }}
          />
          {importedFileName && (
              <span style={{ marginLeft: '10px', fontSize: '0.9rem', color: '#444' }}>
            Imported: {importedFileName}
          </span>
          )}
        </div>
      </div>
  );
};

export default Header;
