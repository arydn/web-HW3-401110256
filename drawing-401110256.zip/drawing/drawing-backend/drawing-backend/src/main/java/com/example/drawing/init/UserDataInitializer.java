package com.example.drawing.init;

import com.example.drawing.model.User;
import com.example.drawing.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class UserDataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;

    public UserDataInitializer(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public void run(String... args) {
        List<String> defaultUsers = List.of("user1", "user2", "user3");
        for (String username : defaultUsers) {
            userRepository.findById(username).orElseGet(() -> {
                return userRepository.save(new User(username));
            });
        }
    }
}
