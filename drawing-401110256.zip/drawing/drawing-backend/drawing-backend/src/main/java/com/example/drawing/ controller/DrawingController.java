package com.example.drawing.controller;

import com.example.drawing.model.Drawing;
import com.example.drawing.service.DrawingService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/drawings")
@CrossOrigin(origins = "http://localhost:3000")
public class DrawingController {

    private final DrawingService service;

    public DrawingController(DrawingService service) {
        this.service = service;
    }

    @GetMapping("/{username}")
    public ResponseEntity<Drawing> getDrawing(@PathVariable String username) {
        System.out.println("🔍 GET drawing for user: " + username);
        Drawing drawing = service.load(username);

        if (drawing == null || drawing.getShapes() == null || drawing.getShapes().isEmpty()) {
            System.out.println("⚠️ No drawing found for user: " + username);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        System.out.println("✅ Found drawing with " + drawing.getShapes().size() + " shapes");
        return ResponseEntity.ok(drawing);
    }

    @PostMapping("/{username}")
    public ResponseEntity<String> saveDrawing(@PathVariable String username, @RequestBody Drawing drawing) {
        try {
            System.out.println("💾 Saving drawing for user: " + username);
            System.out.println("📄 Drawing name: " + drawing.getDrawingName());
            if (drawing.getShapes() == null) {
                System.out.println("❌ Drawing has null shapes");
                return ResponseEntity.badRequest().body("Shapes cannot be null");
            }
            System.out.println("🟠 Number of shapes: " + drawing.getShapes().size());

            drawing.setUsername(username);
            service.save(drawing);

            System.out.println("✅ Drawing saved successfully.");
            return ResponseEntity.ok("Saved successfully");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("❌ Failed to save drawing: " + e.getMessage());
        }
    }
}
