package com.example.drawing.repository;

import com.example.drawing.model.Shape;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ShapeRepository extends JpaRepository<Shape, Long> {
    List<Shape> findByUsername(String username);
    void deleteByUsername(String username);
}
