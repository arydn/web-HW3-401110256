package com.example.drawing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;

import java.util.List;

import com.example.drawing.model.User;
import com.example.drawing.repository.UserRepository;

@SpringBootApplication
public class DrawingBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(DrawingBackendApplication.class, args);
	}

	@Bean
	CommandLineRunner initUsers(UserRepository userRepository) {
		return args -> {
			List<String> defaultUsernames = List.of("user1", "user2", "user3");
			for (String username : defaultUsernames) {
				if (!userRepository.existsById(username)) {
					userRepository.save(new User(username));
				}
			}
		};
	}
}
