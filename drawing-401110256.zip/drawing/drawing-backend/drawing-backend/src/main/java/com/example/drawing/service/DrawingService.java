package com.example.drawing.service;

import com.example.drawing.model.Shape;
import com.example.drawing.model.User;
import com.example.drawing.repository.ShapeRepository;
import com.example.drawing.repository.UserRepository;
import com.example.drawing.model.Drawing;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class DrawingService {

    private final ShapeRepository shapeRepository;
    private final UserRepository userRepository;

    public DrawingService(ShapeRepository shapeRepository, UserRepository userRepository) {
        this.shapeRepository = shapeRepository;
        this.userRepository = userRepository;
    }

    public Drawing load(String username) {
        if (!userRepository.existsById(username)) return null;
        List<Shape> shapes = shapeRepository.findByUsername(username);
        String drawingName = shapes.isEmpty() ? null : shapes.get(0).getDrawingName();
        return new Drawing(username, drawingName, shapes);
    }

    @Transactional
    public void save(Drawing drawing) {
        String username = drawing.getUsername();
        String drawingName = drawing.getDrawingName();

        userRepository.findById(username).orElseGet(() ->
                userRepository.save(new User(username))
        );

        shapeRepository.deleteByUsername(username);

        for (Shape s : drawing.getShapes()) {
            s.setUsername(username);
            s.setDrawingName(drawingName);
        }

        shapeRepository.saveAll(drawing.getShapes());
    }
}
