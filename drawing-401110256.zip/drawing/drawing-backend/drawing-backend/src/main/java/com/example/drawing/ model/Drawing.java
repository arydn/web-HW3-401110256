package com.example.drawing.model;

import java.util.List;

public class Drawing {
    private String username;
    private String drawingName;
    private List<Shape> shapes;

    public Drawing() {
    }

    public Drawing(String username, String drawingName, List<Shape> shapes) {
        this.username = username;
        this.drawingName = drawingName;
        this.shapes = shapes;
    }

    public String getUsername() {
        return username;
    }

    public String getDrawingName() {
        return drawingName;
    }

    public List<Shape> getShapes() {
        return shapes;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setDrawingName(String drawingName) {
        this.drawingName = drawingName;
    }

    public void setShapes(List<Shape> shapes) {
        this.shapes = shapes;
    }
}
